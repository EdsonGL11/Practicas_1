palabra = input('Ingrese una palabra:')

contador = len(palabra)

print(palabra)
print(f'La palabra {palabra} contiene {contador} letras')