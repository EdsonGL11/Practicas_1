print("Ingresa tres números:")

num1 = float(input("Primer número: "))
num2 = float(input("Segundo número: "))
num3 = float(input("Tercer número: "))

mayor = max(num1, num2, num3)

print(f"\nEl número mayor es: {mayor}")
