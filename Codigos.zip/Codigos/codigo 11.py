lista = list(range(10, 0, -1))
print(lista)
