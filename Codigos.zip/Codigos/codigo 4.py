lista = [4,6,8,10,12]

suma_promedio = sum(lista)

promedio = suma_promedio/len(lista)

print(promedio)