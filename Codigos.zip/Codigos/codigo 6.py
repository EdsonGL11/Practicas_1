palabra = input("Escribe una palabra: ")
palabra_invertida = palabra[::-1]

print(f"La palabra '{palabra}' al revés es: '{palabra_invertida}'")
