lista = [3,6,7,9,11]

suma = 0

for i in lista:
    suma += i

print(suma)
    